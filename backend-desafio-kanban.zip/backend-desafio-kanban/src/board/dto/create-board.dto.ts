export class CreateBoardDto {
  name: string;
}
