export class CreateCardDto {
  nameCard: string;
  content: string;
  order: number;
  swimlaneCod: number;
}
