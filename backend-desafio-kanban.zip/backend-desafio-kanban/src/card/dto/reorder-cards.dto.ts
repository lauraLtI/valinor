import { Card } from '../entities/card.entity';

export class ReorderedCardDto {
  boardCod: number;
  cards: Card[];
}
