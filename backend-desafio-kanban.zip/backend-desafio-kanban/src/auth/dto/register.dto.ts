export class RegisterDto {
  emailUser: string;
  passwordUser: string;
  firstName: string;
  lastName: string;
}
