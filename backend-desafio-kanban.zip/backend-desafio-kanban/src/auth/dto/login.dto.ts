export class LoginDto {
  emailUser: string;
  passwordUser: string;
}
